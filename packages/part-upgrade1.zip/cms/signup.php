
<!DOCTYPE html>

<html xmlns:fb="http://ogp.me/ns/fb#"><head><script src="http://www.artix.com//scripts/jquery-1.8.3.min.js"></script><!--[if lte IE 8]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]--><script src="http://www.artix.com//scripts/artixCMSFunctions.js"></script><script src="http://www.artix.com//themes/artix.com/scripts/artixSiteFunctions.js"></script><script src="http://www.artix.com//Scripts/jquery.validate.min.js"></script><script src="http://www.artix.com//Scripts/jquery.validate.unobtrusive.min.js"></script><script src="http://www.artix.com//Scripts/script.swfobject.js"></script><link type="text/css" rel="Stylesheet" href="http://www.artix.com//themes/artix.com/css/siteStyles.css"><link rel="alternate" type="application/rss+xml" title="Artix Entertainment News" href="http://www.artix.com/designnotes/feed"><link rel="shortcut icon" href="https://fbstatic-a.akamaihd.net/rsrc.php/yP/r/Ivn-CVe5TGK.ico" type="image/x-icon"><link rel="icon" type="image/x-icon" href="http://www.artix.com//themes/artix.com/favicon.ico"><title>WiseX &bull; Play Now!</title><script src="http://www.artix.com//scripts/jquery.cycle.lite.js"></script><script>
        var divwidth = 1758; 				//The actual width of the slider elements
        var bgHeight = 350; 					//The height of the slider background elements
        var popHeight = 96; 					//The height of the slider foreground elements
        var animTime = 7000; 				//The time the slide stays on screen (in milliseconds ie: 1s = 1000ms)
        var transitionSpeed = 800; 			//The time spent on transitions between slides (in milliseconds ie: 1s = 1000ms)
        var bgelement = ".hmBanner"; 		//The JQuery selector for the background element

        var sliderElements = new Array();
        sliderElements[0] = new Array("http://www.artix.com//themes/artix.com/css/siteImages/banners/homePage/banner-battleon.jpg", "", true, "/cms/playme/", "");
        sliderElements[1] = new Array("http://www.artix.com//themes/artix.com/css/siteImages/banners/homePage/banner-oversoul.jpg", "", true, "/cms/playme/", "");
        sliderElements[2] = new Array("http://www.artix.com//themes/artix.com/css/siteImages/banners/homePage/banner-heromart.jpg", "", true, "/cms/playme/", "");
        sliderElements[3] = new Array("http://www.artix.com//themes/artix.com/css/siteImages/banners/homePage/banner-createaccount.jpg", "", true, "/cms/playme/", "");
        sliderElements[4] = new Array("http://www.artix.com//themes/artix.com/css/siteImages/banners/homePage/banner-calendar.jpg", "", true, "/", "");
    </script><script src="http://www.artix.com//themes/artix.com/scripts/slider.js"></script><!--[if lte IE 7]>
    <style>
        .box1{margin: 8px 9px 10px 25px;}
        .promoboxes{float:left;}
        .promoboxes a{height:177px;}
    </style>
    <![endif]--></head><body>
            

<?php
include('battlebar.php')
?>
	</div>
</nav>
<div class="subBanner">
	<div class="cblock">
		<span class="pagename"> </span>
	</div>
</div>	

    <tr>
	<div class="contentContainer">
    <section class="cblock content">
    <div class="happeningNowHeader sprite headerTitle">Register<a href="" class="rFloat hmBtn"><span
    <td width="960" height="550" >
		</div>
			<div class="post hmboxesBGC"><br />

<center><a href="/cms/"><strong>Back To HomePage</strong></a>
<body><div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><body>
				<div id="fb-root" name="fb-root"></div>
				<div id="flashContent" name="flashContent">
					<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" id="u35941" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="960" height="550">
                      <param name="movie" value="playme/gamefiles/newuser/newuser.swf" />
                      <param name="LOOP" value="false" />
                      <param name="SCALE" value="exactfit" />
                      <param name="allowScriptAccess" value="always" />
                      <param name="allowFullScreen" value="true" />
                      <param name="menu" value="false" />
                      <param name="wmode" value="window" />
                      <param name="FlashVars" value="&sLang=en" />
                      <embed id="gameSWF" src="playme/gamefiles/newuser/newuser.swf" width="958" height="550" loop="false" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" scale="exactfit" allowscriptaccess="always" allowFullScreen="true" menu="false" flashvars="&sLang=en"></embed>
                    </object>
				<div class="fb-like" data-href="https://www.facebook.com/WiseX" data-send="false" data-width="450" data-show-faces="true"></div>
				</div>
				
				
			</td>
    </tr>
    
  </table>

  </footer>
<a href="#" class="sprite logo" title="WiseX Team Home Page"><span>Flash Entertainment Home Page</span></a>
	<div class="usersonlineContainer">
		<div class="sprite usersonline">Server Online !</div>
	</div>
<div id="modalDark" onclick='openModalBox("0px", false);'></div>
</body>
</html>
  
  


</body>
</html>
