    <footer class="footer">
    <div class="footerContainer">
        <div class="footerSpacer"></div>
        <div class="footerNav">
            <div class="artixContainer">
                <span class="footerTitle">Artix.Com</span>
                <div class="footerNavContainer">
                    <a href="/games">Games</a>
                    <a href="#">About</a>
                    <a href="/pages/community">Community</a>
                    <a href="http://portal.battleon.com/help/">Support</a>
                    <a href="http://portal.battleon.com/store/points/">Store</a>
                    <a href="/pages/Contact-Us">Contact</a>
                </div>
            </div>
            <div class="gamesContainer">
                <span class="footerTitle">Games</span>
                <div class="footerNavContainer">
                    <div class="lc">
                        <a href="http://www.aq.com/">AdventureQuest Worlds</a>
                        <a href="http://epicduel.artix.com/">EpicDuel</a>
                        <a href="http://www.dragonfable.com/">DragonFable</a>
                        <a href="http://www.mechquest.com/">MechQuest</a>
                        <a href="http://herosmash.artix.com/">HeroSmash</a>
                        <a href="http://www.battle.com/">AdventureQuest</a>
                    </div>
                    <div class="rc">
                        <a href="http://www.bladehaven.com/">Bladehaven</a>
                        <a href="http://www.ebilgames.com/">EbilGames</a>
                        <a href="http://OverSoul.artix.com">OverSoul</a>
                        <a href="http://ponyvspony.com/">Pony vs Pony</a>
                    </div>
                </div>
            </div>
            <div class="accountContainer">
                <span class="footerTitle">Account</span>
                <div class="footerNavContainer">
                    <a href="http://portal.battleon.com/help/p-accounts.asp">Can't log in?</a>
                    <a href="#">Create Account</a>
                    <a href="#">Account Settings</a>
                    <a href="http://portal.battleon.com/store/points/howtouse.asp">Redeem Codes</a>
                </div>
            </div>
            <div class="supportContainer">
                <span class="footerTitle">Support</span>
                <div class="footerNavContainer">
                    <a href="http://portal.battleon.com/help/">Customer Support</a>
                    <a href="http://portal.battleon.com/help/p-technical.asp">Tech Support</a>
                    <a href="http://portal.battleon.com/help/p-payments.asp">Billing Support</a>
                    <a href="http://portal.battleon.com/account/lostpassword.asp">Password Recovery</a>
                </div>
            </div>
            <div class="communityContainer">
                <span class="footerTitle">Community</span>
                <div class="footerNavContainer">
                    <a href="http://forums2.battleon.com/f/default.asp">BattleOn! Forums</a>
                    <a href="http://forums2.battleon.com/zardian">The Zardian</a>
                    <a href="http://portal.battleon.com/staff/">The AE Team</a>
                </div>