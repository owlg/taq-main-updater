<section class="blackTopper">
	<div class="cblock">
		<div class="blackBarContent">
			<a href="/cms/play.php" class="supportTopLink">Play WiseX II<span class="fsprite"></span></a>
		</div>
	</div>
</section>
<nav class="battlebar">
	<div class="cblock">
			<div class="loginContainer">
				<span><a class="login fsprite" id="loginbutton" onclick="loginClick()" href="/cms/play.php"><span>Play !</span>&nbsp;</a>or<a class="createLink" id="createAccountBar" onclick="createAccount()" href="/cms/signup.php">Create an Account!</a></span>
			</div>
		<ul id="siteNav">
			<li class="topLevel"><a href="/cms/">Home</a></li>
			<li class="topLevel games"><a href="#">Games <span class="arrow sprite"></span></a>
				<ul>
				<li class="game-aqw">
					<a class="gameLink" title="WiseX II" href="#"><div class="desc"><strong>FlashWorlds II</strong>Private Server</div></a>
					<span class="dn"><a title="WiseX Design Notes" href="#"><span>FlashWorlds Design Notes</span></a></span>
					<span class="gp"><a title="Play WiseX II" href="/cms/playme/"><span>Play FlashWorlds II</span></a></span>                            
				</li>
				</ul>
			</li>
			<li class="topLevel"><a href="/cms/signup.php">Register</a></li>
			<li class="topLevel shop"><a href="#">Shop <span class="arrow sprite"></span></a>
				<ul>
					<li class="heromart fsprite">
						<a href="http://www.heromart.com"><span><strong>Heromart</strong><br />Real-Life Merchandise</span></a>
					</li>
					<li class="artixPoints fsprite">
						<a href="http://portal.battleon.com/store/points/"><span><strong>Flash Points</strong><br />Get Flash Points</span></a>
					</li>
				</ul>
			</li>
		</ul>