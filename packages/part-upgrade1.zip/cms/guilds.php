<?php
/**
  * HiddenProject Content Management System - Guilds
  * @author Naufal Hardiansyah  (www.infinity-arts.com)
  * @date created 0/0/000
  * @last update 1/15/2012
  *
  * DEVELOPER PLEASE NOTE
  * You may edit and/or improve it any further it as long as you do not remove the original author name.
  * @license http://opensource.org/licenses/gpl-3.0.html GNU Public License
**/
/** PREPARE ELEMENTS **/
require 'classes/class.content.php';
require 'classes/class.core.php';
require 'config.inc.php';

/** INITIALIZES CLASSES **/
$index = new HiddenProjectCMS();
$core = new Core();

/** CONFIGURES MYSQL AUTHORIZATION DATA **/
$MySQL = new stdClass();
$MySQL->HOST = 'localhost';
$MySQL->USER = 'root';
$MySQL->PASS = '';
$MySQL->DATA = 'hiddenproject';
$index->MYSQL = $MySQL;

/** INITIALIZES ELEMENTS **/
$index->Initialize('Connection');
$index->Initialize('Settings');
$index->Initialize('UsersOnline');
$index->Initialize('Sponsor');

/** INITIALIZES CONTENT VARIABLES **/
$index->SITE->SHOWOPTIONS = false;
$index->SITE->DESCRIPTION = 'Guilds';
$index->SITE->SUBTITLE = 'Account Login';

/** INITIALIZES PRE-DEFINED USER DATAS **/
$index->USER->LOGGEDIN = $core->UserData['Login'];
$index->USER->CURRENTURL = $core->UserData['Location'];

/** BEGIN USER PAGE HANDLER (CUSTOMIZED FOR: GUILD) **/
if ($core->UserData['Login']) {
    /** VALIDATES USER SESSION **/
    if (!$core->Validate('UserData', array( 0 => $index )))
        header('Location: ' . $index->USER->CURRENTURL);

    /** PARSE USER REQUEST **/
    switch (strtoupper(key($_GET))){
        case 'GUILDCREATION':
            if (isset($_POST['guildName']) AND isset($_POST['guildDescription'])) {
                $_POST['guildName'] = $index->MySQLi('EscapeString', array( 0 => trim($_POST['guildName']) ));
                $_POST['guildDescription'] = htmlentities(trim($_POST['guildDescription']));

                /** VALIDATES POST VARIABLES **/
                if (trim($_POST['guildName']) == '' OR trim($_POST['guildDescription']) == '')
                    $index->SendResponse('Guild Name and/or Guild Description required!', 2);
                else if (!preg_match('/^[\sa-z0-9\x99\xe2\x84\xa2]+$/i', $_POST['guildName']))
                    $index->SendResponse('Invalid Guild Name!', 2);
                else {
                    /** VALIDATES USER DATA **/            
                    $sql = $index->MySQLi('Query', array( 0 => "SELECT id FROM `meh_guilds` WHERE Founder='{$core->UserData['id']}'" ));
                if (($core->UserData['Coins'] - 1000) <= 0)
                   $index->SendResponse('You do not have enough AdventureCoins to make a guild! Purchase them <a href="shop.php">here</a>!', 2);
                    else if ($sql->num_rows > 0)
                   $index->SendResponse('Only allowed <b>one guild per user</b> at the moment!', 2);
                    else {
                        /** BEGIN GUILD CREATION **/
                        $index->MySQLi('Query', array( 0 => "INSERT INTO `meh_guilds` (`Name`, `Description`, `Founder`, `Members`, `Pending`, `Type`, `DateCreated`) VALUES ('{$_POST['guildName']}', '{$_POST['guildDescription']}', '{$core->UserData['id']}', '{$core->UserData['id']}', '', '1', '{$core->CurrentDate}');" ));
                        /** RETRIEVE NEW GUILD ID **/
                  $sqlQuery = $index->MySQLi('Query', array( 0 => "SELECT id FROM `meh_guilds` WHERE Name='{$_POST['guildName']}'" ));
                        /** UPDATE USER DATA **/
                        $index->MySQLi('Query', array( 0 => "UPDATE `meh_users` SET GuildID={$objGuild->id}, Coins=Coins-1000 WHERE id={$core->UserData['id']}" ));
                        $index->SendResponse('You have successfuly created a guild! Let your friends know about your guild and tell them to join!', 1);
                    }
                }
            }

            /** INITIALIZES CONTENT **/
            $index->SITE->SUBTITLE = 'Create your own guild!';
            $index->SITE->CONTENT = $index->GetCMSTemplate('guilds.creation');
            break;
        case 'GUILDINFO':
            /** VALIDATES GUILD ID **/
            if (isset($_GET['id'])) {
                /** PARSES GUILD DATA **/
                $GuildId = (int) $index->MySQLi('EscapeString', array( 0 => trim($_GET['id']) ));
                $SqlQuery = $index->MySQLi('Query', array( 0 => "SELECT * FROM `meh_guilds` WHERE id=" . $GuildId ));
                /** VALIDATES GUILD **/
                if ($SqlQuery->num_rows > 0) {
                    /** INITIALIZES GUILD DATA **/
                    $objGuild = $SqlQuery->fetch_object();
               
                    /** INITIALIZES CUSTOM GUILD VARIABLES **/
               $objGuild->TotalMembers = 0;
               $objGuild->PendingMembers = 0;
               $objGuild->MembersList = null;
               $objGuild->PendingList = null;
                    $objGuild->FounderName = null;
                    $objGuild->OptionsTitle = 'Available Options';
                    $objGuild->Options = $objGuild->Type > 0 ? '
                        <form action="{UDATA_CURRENTURL}" method="post" name="form1" class="nice">
                            <input value="reqjoin" name="guild" type="hidden" />
                            <button type="submit" class="brown">Request Join</button>
                        </form>' : null;

                    /** PARSES GUILD MEMBERS **/
                    $data['line'] = explode(",", $objGuild->Members);
                    for ($i = 0; $i < $count = count($data['line']); $i++) {
                        if (strlen($data['line'][$i]) < 1) continue;
                        $sql = $index->MySQLi('Query', array( 0 => "SELECT Username FROM `meh_users` WHERE id='{$data['line'][$i]}'" ));
                        if ($sql->num_rows > 0) {
                            $objMember = $sql->fetch_object();
                            $objGuild->TotalMembers++;

                            if ($data['line'][$i] == $objGuild->Founder) {
                                $objGuild->FounderName = $objMember->Username;
                                $objMember->Username = '<b>' . $objMember->Username . '</b>';
                            } else {
                                if ($objGuild->Founder == $core->UserData['id'])
                                    $objMember->Username = $objMember->Username . " - <a href='{UDATA_CURRENTURL}&kick={$data['line'][$i]}'>Kick</a>";         
                            }
                            $objGuild->MemberList .= "<li>{$objMember->Username}</li>";
                        } else $index->SendResponse("Warning: User ID '{$data['line'][$i]}' not found!", 4);
                    }

                    /** PARSES GUILD PENDING USERS **/
                    $data['line'] = explode(",", $objGuild->Pending);
                    for ($i = 0; $i < $count = count($data['line']); $i++) {
                        if (strlen($data['line'][$i]) < 1) continue;
                        $sql = $index->MySQLi('Query', array( 0 => "SELECT Username FROM `meh_users` WHERE id='{$data['line'][$i]}'" ));
                        $objMember = $sql->fetch_object();
                        $objGuild->PendingMembers++;

                        if ($objGuild->FounderName == $core->UserData['Username'])
                            $objMember->Username = $objMember->Username . " - <a href='{UDATA_CURRENTURL}&approve={$data['line'][$i]}'>Approve</a> | <a href='{UDATA_CURRENTURL}&disapprove={$data['line'][$i]}'>Disapprove</a>";                       
                  
                        $objGuild->PendingList .= "<li>{$objMember->Username}</li>";
                        if ($data['line'][$i] == $core->UserData['id']) {
                            $objGuild->Options = $objGuild->Type != "edit" ? null : $objGuild->Options;
                            $index->SendResponse('Your request has been sent, please wait for this guild founder\'s approvals.', 4);
                        }
                    }

                    /** CHECKS IF USER IS GUILD'S FOUNDER **/
                    if ($objGuild->Founder == $core->UserData['id']) {
                        $objGuild->Options = null;
                        $objGuild->OptionsTitle = 'Edit your guild';
                        $objGuild->Options = '
                            <form action="{UDATA_CURRENTURL}" method="post" name="form1" class="nice">
                                <input value="edit" name="guild" type="hidden" />
                                <p class="left">
                                    <label>Guld Name:</label>
                                    <input name="guildName" type="text" class="inputText" id="guildName" value="' . $objGuild->Name . '">
                              </p>
                                <p class="right">
                                    <label>Guild Description:</label>
                                   <textarea cols="" rows="5" class="inputText_wide" name="guildDescription">' . $objGuild->Description . '</textarea>
                                    <br clear="all">
                                    <button type="submit" class="brown">Submit</button>
                                </p>
                                <div class="clear"></div>
                            </form>';
                        }
               
                    /** CHECKS MEMBERS / PENDING USERS LIST **/
                    $objGuild->MemberList = $objGuild->MemberList == null ? '<font style="color: red;">No available members</font>' : '<ul>' . $objGuild->MemberList . '</ul>';
                    $objGuild->PendingList = $objGuild->PendingList == null ? '<font style="color: red;">No available members</font>' : '<ul>' . $objGuild->PendingList . '</ul>';
               
                    /** APPROVE MEMBERSHIP **/
                    if (isset($_GET['approve'])) {
                        if ($objGuild->FounderName == $core->UserData['Username']) {
                            $core->HandleUser('JoinGuild', array( 0 => $GuildId, 1 => $index, 2 => false, 3 => $_GET['approve']));
                            header('Location: guilds.php?guildinfo&id=' . $GuildId);
                        }
                    } /** DISAPPROVE MEMBERSHIP **/ else if (isset($_GET['disapprove'])) {
                        if ($objGuild->FounderName == $core->UserData['Username']) {
                            $core->HandleUser('ResignGuild', array( 0 => $GuildId, 1 => $index, 2 => false, 3 => $_GET['approve']));
                            header('Location: guilds.php?guildinfo&id=' . $GuildId);
                        }
                    } /** REMOVE MEMBERSHIP **/ else if (isset($_GET['kick'])) {
                        if ($objGuild->FounderName == $core->UserData['Username'] OR $core->UserData['id'] == $_GET['kick']) {
                            $NewMembers = null;
                            $data['line'] = explode(",", $objGuild->Members);
                            for ($i = 0; $i < $count = count($data['line']); $i++) {
                                if (strlen($data['line'][$i]) < 1 OR $_GET['kick'] == $data['line'][$i]) continue;
                                $NewMembers .= $NewMembers == null ? $data['line'][$i] : ',' . $data['line'][$i];
                            }

                            $index->MySQLi('Query', array( 0 => "UPDATE `meh_guilds` SET Members='{$NewMembers}' WHERE id=" . $GuildId ));
                            header('Location: guilds.php?guildinfo&id=' . $GuildId);
                        }
                    } /** SET AS DEFAULT **/ else if (isset($_GET['join'])) {
                        $data['line'] = explode(",", $objGuild->Members);
                        for ($i = 0; $i < $count = count($data['line']); $i++) {
                            if (strlen($data['line'][$i]) < 1) continue;
                            if ($data['line'][$i] == $core->UserData['id']) {
                                $index->MySQLi('Query', array( 0 => "UPDATE `meh_users` SET GuildID={$GuildId} WHERE id=" . $core->UserData['id'] ));
                                $index->SendResponse("'{$objGuild->Name}' is now your default guild!", 1);
                                break;
                            }
                        }
                    }

                    /** PARSE USER REQUEST **/
                    if (isset($_POST['guild'])) {
                        switch($_POST['guild']) {
                            case 'reqjoin':
                                $core->Initialize('userjoinguild', array( 0 => $GuildId, 1 => $index, 2 => true ));
                                $index->SendResponse('Your request has been successfuly sent, please wait for the owner approvals.', 1);
                                break;
                            case 'edit':
                                if (isset($_POST['guildName']) AND isset($_POST['guildDescription'])) {
                                    $_POST['guildName'] = trim($_POST['guildName']);
                                    $_POST['guildDescription'] = htmlentities(trim($_POST['guildDescription']));
                                    $guildDate = date('Y-m-d h:i:s');
                                    if (trim($_POST['guildName']) == '' OR trim($_POST['guildDescription']) == '')
                                        $index->SendResponse('Guild Name and/or Guild Description required!', 2);
                                    else if (!preg_match('/^[\sa-z0-9\x99\xe2\x84\xa2]+$/i', $_POST['guildName']))
                                        $index->SendResponse('Invalid Guild Name!', 2);
                                    else {
                                        $index->MySQLi('Query', array( 0 => "UPDATE `meh_guilds` SET Name='{$_POST['guildName']}', Description='{$_POST['guildDescription']}' WHERE id={$objGuild->id}" ));
                                    $index->SendResponse('You have successfuly updated your guild!', 1);
                                    }
                                }
                                break;
                            case 'default':
                                $index->SendResponse('Invalid Request.', 3);
                                break;
                        }
                    }
               
                    /** INITIALIZES CONTENT GUILD OBJECT **/
                    $index->GUILD = $objGuild;
                } else $index->SendResponse('Guild not found!', 2);
            }

            /** INITIALIZES CONTENT **/
            $index->SITE->CONTENT = $index->GetCMSTemplate('guilds.info');
            break;
        default:      
            /** INITIALIZES CONTENT **/
            $index->Initialize('Guilds', array( 0 => $core ));
            $index->SITE->CONTENT = $index->GetCMSTemplate('guilds.default');
        break;
    }
} else {
    if (isset($_POST['txtUsername']) AND isset($_POST['txtPassword'])) {
        $token = $core->Initialize('UserToken', array(0 => $_POST['txtPassword'], 1 => $_POST['txtUsername']));
        $sql = $index->MySQLi('Query', array( 0 => "SELECT * FROM `meh_users` WHERE password='{$token}'" ));
        if ($sql->num_rows > 0) {
            $_SESSION['udata'] = $sql->fetch_assoc();
            header('Location: ' . $index->USER->CURRENTURL);
        } else {
            $core->DestroySessions();
            $index->SendResponse('Invalid Credentials', 2);
        }
    }
    /** INIT LOGIN TEMPLATE **/
    $index->SITE->CONTENT = $index->GetCMSTemplate('manage.login');
}
/*********************************************************/

/** SEND OUTPUT **/
print ($index->FlushContent());
exit();
?>