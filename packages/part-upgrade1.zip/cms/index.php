<?php

/** READ CONFIGURATIONS **/
require 'config.inc.php';

/** DEFINES NEEDED CLASSES **/
DefineClass('Handler');
DefineClass('Content');
DefineClass('Core');
DefineClass('BBCodes');

/** INITIALIZES CLASSES **/
$handler = new ErrorHandler();
$content = new HiddenProjectCMS();
$advcore = new Core();
$bbcodes = new BBCodes();

/** CONFIGURES MYSQL DATA **/
$MySQL = new stdClass();
$MySQL->HOST = MYSQL_HOST; 
$MySQL->USER = MYSQL_USER;
$MySQL->PASS = MYSQL_PASS;
$MySQL->DATA = MYSQL_DATA;
$content->MYSQL = $MySQL;

/** INITIALIZES CLASS CONTENT VARIABLES **/
$content->Initialize('Connection');
$content->Initialize('Settings');
$content->Initialize('UsersOnline');
$content->Initialize('Sponsor');

/** ENABLES/DISABLES GAME AND REGISTRATION LINK **/
$content->SITE->SHOWOPTIONS = true;

/** INITIALIZES USER STATUS **/
$content->USER->LOGGEDIN = $advcore->UserData['Login'];

/***************** BEGINS OUTPUT INITIALIZATION *****************/
switch (key($_GET)) {
    case 'explorableareas':
        /** INITIALIZES OUTPUT SETTINGS FOR: EXPLORABLE AREAS **/
        $content->Initialize('AvailableAreas');	
        $content->SITE->SHOWOPTIONS = false;
        $content->SITE->DESCRIPTION = 'Available Maps';
        $content->SITE->CONTENT = $content->GetCMSTemplate('main.availablemaps');
        break;
    case 'top100characters':
        /** INITIALIZES OUTPUT SETTINGS FOR: TOP 100 CHARACTERS **/
        $content->Initialize('Top100Characters');
        $content->SITE->SHOWOPTIONS = false;
        $content->SITE->DESCRIPTION = 'Top 100 Players';
        $content->SITE->CONTENT = $content->GetCMSTemplate('main.top100');
        break;
    case 'ourterms':
        /** INITIALIZES OUTPUT SETTINGS FOR: TERMS OF SERVICE **/
        $content->SITE->SHOWOPTIONS = false;
        $content->SITE->DESCRIPTION = 'Terms and Conditions';
        $content->SITE->CONTENT = $content->GetCMSTemplate('main.termsofservice');
        break;
    case 'usersvideos':
        /** INITIALIZES OUTPUT SETTINGS FOR: USERS VIDEOS **/
        $content->SITE->SHOWOPTIONS = false;
        $content->SITE->DESCRIPTION = 'Videos';
        $content->SITE->CONTENT = $content->GetCMSTemplate('main.usersvideos');
        break;
    default:
        /** INITIALIZES OUTPUT SETTINGS FOR: DEFAULT HOMEPAGE **/
        $content->SITE->JSCRIPTS = '';
        $content->Initialize('News', array( 0 => $bbcodes ));
        $content->SITE->DESCRIPTION = 'Home';
        break;
}
/****************************************************************/

/** PRINT FINAL OUTPUT **/
print ($content->FlushContent());
exit();
?>
