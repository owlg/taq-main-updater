<?php
/**
  * HiddenProject Content Management System - Account Manager
  * @author Naufal Hardiansyah  (www.infinity-arts.com)
  * @date created 0/0/000
  * @last update 1/15/2012
  *
  * DEVELOPER PLEASE NOTE
  * You may edit and/or improve it any further it as long as you do not remove the original author name.
  * @license http://opensource.org/licenses/gpl-3.0.html GNU Public License
**/
/** READ CONFIGURATIONS **/
require 'config.inc.php';

/** DEFINES NEEDED CLASSES **/
DefineClass('Handler');
DefineClass('Content');
DefineClass('Core');

/** INITIALIZES CLASSES **/
$index = new HiddenProjectCMS();
$core = new Core();

/** CONFIGURES MYSQL AUTHORIZATION DATA **/
$MySQL = new stdClass();
$MySQL->HOST = MYSQL_HOST; 
$MySQL->USER = MYSQL_USER;
$MySQL->PASS = MYSQL_PASS;
$MySQL->DATA = MYSQL_DATA;
$index->MYSQL = $MySQL;

/** INITIALIZES CLASS CONTENT VARIABLES **/
$index->Initialize('Connection');
$index->Initialize('Settings');
$index->Initialize('UsersOnline');
$index->Initialize('Sponsor');

/** INITIALIZES PRE-DEFINED USER VARIABLES **/
$index->USER->LOGGEDIN = $core->UserData['Login'];
$index->USER->CURRENTURL = $core->UserData['Location'];

/** INITIALIZES CONTENT VARIABLES **/
$index->SITE->SHOWOPTIONS = false;
$index->SITE->DESCRIPTION = 'Account Management';
$index->SITE->SUBTITLE = 'Account Management Login';

/** BEGIN USER PAGE HANDLER (CUSTOMIZED FOR: ACCOUNT MANAGER) **/
if ($core->UserData['Login']) {
    /** VALIDATES USER SESSION **/
    if (!$core->Validate('UserData', array( 0 => $index )))
        header('Location: ' . $index->USER->CURRENTURL);

    /** REDIRECT USER **/
    if (isset($_GET['goto']) AND !isset($_GET['logout']))
        header('Location: ' . $_GET['goto']);

    /** HANDlES CLIENT REQUEST **/
    switch (strtolower(key($_GET))) {
        case 'changepassword':
            if (isset($_POST['txtNewPassword']) AND isset($_POST['txtRetypePassword'])) {
                $_POST['txtNewPassword'] = trim($_POST['txtNewPassword']);
                $_POST['txtRetypePassword'] = trim($_POST['txtRetypePassword']);
                if (trim($_POST['txtNewPassword']) == '' OR trim($_POST['txtRetypePassword']) == '')
                    $index->SendResponse('New password required!', 2);
                else if ($_POST['txtNewPassword'] != $_POST['txtRetypePassword'])
                    $index->SendResponse('Retyped password did not match!', 2);
                else {
                    $token = $core->Initialize('UserToken', array( 0 => $_POST['txtNewPassword'], 1 => $core->UserData['Username'] ));	
                    $index->MySQLi('Query', array( 0 => "UPDATE `meh_users` SET Password='{$token}' WHERE Username='{$core->UserData['Username']}'" ));
                    $sql = $index->MySQLi('Query', array ( 0 => "SELECT * FROM `meh_users` WHERE password='{$token}'" ));
                    if ($sql->num_rows > 0) {
                        $_SESSION['udata'] = $sql->fetch_assoc();
                        $core->UserData = $_SESSION['udata'];
                        $index->SendResponse('Your password has been successfully changed.', 2);
                    } else { 
                        $core->DestroySessions();
                        header('Location: ' . $core->UserData['Location']);
                    }
                }
            }
			
            $index->SITE->CONTENT = $index->GetCMSTemplate('manage.password');
            break;
        case 'changeemail':
            if (isset($_POST['txtNewEmail']) AND isset($_POST['txtRetypeEmail'])) {
                $_POST['txtNewEmail'] = $index->__mysqlEscapeString(trim($_POST['txtNewEmail']));
                $_POST['txtRetypeEmail'] = $index->__mysqlEscapeString(trim($_POST['txtRetypeEmail']));
                if (trim($_POST['txtNewEmail']) == '' OR trim($_POST['txtRetypeEmail']) == '')
                    $index->SendResponse('New email required!', 2);
                else if ($_POST['txtNewEmail'] != $_POST['txtRetypeEmail'])
                    $index->SendResponse('Retyped email did not match!', 2);
                else if (!$core->__initialize('useremailvalidator', array( 0 => $_POST['txtNewEmail'] ))) {
                    $index->SendResponse('Invalid Email Address!', 2);
                } else {
                    $token = $core->UserData['Password'];
                    $index->MySQLi('Query', array( 0 => "UPDATE `meh_users` SET Email='{$_POST['txtNewEmail']}' WHERE Username='{$core->UserData['Username']}'" ));
                    $sql = $index->MySQLi('Query', array( 0 => "SELECT * FROM `meh_users` WHERE password='{$token}'" ));
                    if ($sql->num_rows > 0) {
                        $_SESSION['udata'] = $sql->fetch_assoc();
                        $core->UserData = $_SESSION['udata'];
                        $index->SendResponse('Your email has been successfully changed.', 2);
                    } else { 
                        $core->DestroySessions();
                        header('Location: ' . $core->UserData['Location']);
                    }
                }
            }
			
            $index->USER->EMAIL = $core->UserData['Email'];
            $index->SITE->CONTENT = $index->GetCMSTemplate('manage.email');
            break;
        case 'logout':
            $core->DestroySessions();
            header('Location: ' . (isset($_GET['goto']) ? $_GET['goto'] : 'manage.php'));
            break;
        default:
            $index->USER->NAME = $core->UserData['Username'];
            $index->USER->EMAIL = $core->UserData['Email'];
            $index->USER->EMAILSTATUS = ($core->UserData['ActivationFlag'] == 5 ? 'Confirmed' : 'Unconirmed');
            $index->USER->EMAILSTATUSCOLOR = ($core->UserData['ActivationFlag'] == 5 ? 'color: Green;' : 'color: Red;');	
            $index->USER->DATECREATED = $core->UserData['DateCreated'];
            $index->USER->LASTACCESS = '12/22/2011 2:40:00 PM';
            $index->USER->UPGEXPIRE = $core->UserData['UpgradeDays'] >= 0 ? $core->UserData['UpgradeExpire'] : 'Not currently a V.I.P!';
            $index->USER->UPGMESSAGE = $core->UserData['UpgradeDays'] >= 0 ? 'Extend Your V.I.P-ship!' : 'Become One!';
            $index->SITE->CONTENT = $index->GetCMSTemplate('manage.overview');
        break;
    }
} else {
    /** INITIALIZES CONTENT **/
    $index->SITE->CONTENT = $index->GetCMSTemplate('manage.login');
	
    /** CHECK USER POST DATA **/
    if (isset($_POST['txtUsername']) AND isset($_POST['txtPassword'])) {
        /** INITIALIZES LOGIN RESULT **/
        $result = array();
        $result[0] = $core->HandleUser('Login', array( 0 => $index, 1 => $_POST['txtUsername'], 2 => $_POST['txtPassword'] ));	
        $result[1] = json_decode($result[0]);

        /** HANDLES REDIRECTIONS **/
        if ($result[1]->{'output'} == 'success')
            header('Location: ' . $index->USER->CURRENTURL);        
    }
}
/*********************************************************/

/** SEND OUTPUT **/
print ($index->FlushContent());
exit();
?>