<?php
/** SERVER INFORMATION **/
define('SERVER_NAME', 'TAQ Wisex');
define('SERVER_DESCRIPTION', null);
define('SERVER_FACEBOOK', 'aqwps');
define('SERVER_OWNER_NAME', 'WiseX');
define('SERVER_OWNER_EMAIL', 'noemail@owlg.org');

/** MYSQL DATA CONFIGURATIONS **/
define('MYSQL_HOST', 'localhost');
define('MYSQL_USER', 'root');
define('MYSQL_PASS', '');
define('MYSQL_DATA', 'wisexdbdb');

define('PAYPAL_EMAIL', 'chewjianyue2012@gmail.com');
define('PAYPAL_SURL', '/shop.php?gen');
define('PAYPAL_CURL', '/shop.php?error');
define('PAYPAL_RMETHOD', '2');
define('PAYPAL_PMETHOD', 'CAD');
define('PAYPAL_CCODE', 'CAD');
define('PAYPAL_LANG', 'CA');
define('PAYPAL_SERVER', 'https://www.paypal.com/cgi-bin/webscr');

define('CMS_FILE_PATH', dirname(__FILE__) . "/");
define('CMS_DEBUG_MODE', true);
define('CMS_ADVERTISEMENTS', false);
define('CMS_ROOT', '/cms/');

define('CMS_CLASS_ERROR', 'classes/class.handler.php');
define('CMS_CLASS_MAIN', 'classes/class.content.php');
define('CMS_CLASS_CORE', 'classes/class.core.php');
define('CMS_CLASS_DATA', 'classes/class.data.php');
define('CMS_CLASS_BBCODES', 'classes/class.bbcodes.php');

function DefineClass($ClassName = null) {
    switch (strtoupper($ClassName)) {
        case 'HANDLER':
            $CLASS = CMS_FILE_PATH . CMS_CLASS_ERROR;
            if (file_exists($CLASS)) require $CLASS; else UrgentMessage('Class ' . $ClassName . ' (' . $CLASS . ') does not exist!', __LINE__, __FILE__);
            break;
        case 'CONTENT':
            $CLASS = CMS_FILE_PATH . CMS_CLASS_MAIN;
            if (file_exists($CLASS)) require $CLASS; else UrgentMessage('Class ' . $ClassName . ' (' . $CLASS . ') does not exist!', __LINE__, __FILE__);
            break;
        case 'CORE':
            $CLASS = CMS_FILE_PATH . CMS_CLASS_CORE;
            if (file_exists($CLASS)) require $CLASS; else UrgentMessage('Class ' . $ClassName . ' (' . $CLASS . ') does not exist!', __LINE__, __FILE__);
            break;
        case 'DATA':
            $CLASS = CMS_FILE_PATH . CMS_CLASS_DATA;
            if (file_exists($CLASS)) require $CLASS; else UrgentMessage('Class ' . $ClassName . ' (' . $CLASS . ') does not exist!', __LINE__, __FILE__);
            break;
        case 'BBCODES':
            $CLASS = CMS_FILE_PATH . CMS_CLASS_BBCODES;
            if (file_exists($CLASS)) require $CLASS; else UrgentMessage('Class ' . $ClassName . ' (' . $CLASS . ') does not exist!', __LINE__, __FILE__);
            break;
    }
}

function UrgentMessage($text = 'No given message', $line = __LINE__, $file = __FILE__) {
    header('Content-Type: text/plain');
    print ("$text - " . date("F j, Y, g:i a"));
    print ("\nLocation: $file ($line)");
    exit(1);
}
?>
